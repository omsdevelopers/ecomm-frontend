"use strict";
exports.id = 168;
exports.ids = [168];
exports.modules = {

/***/ 9473:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "bA": () => (/* binding */ cartList),
/* harmony export */   "rQ": () => (/* binding */ fetchData),
/* harmony export */   "x4": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, uuid__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, uuid__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const api = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "http://ecomm-api.test/api"
});
const fetchData = async (url)=>{
    try {
        const response = await api.get(url);
        return response.data;
    } catch (error) {
        console.error("Error fetching data:", error);
        throw error; // You can handle errors as needed
    }
};
const login = async (email, password)=>{
    try {
        const response = await api.post("/auth/login", {
            email,
            password
        });
        const token = response.data.token;
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(response.data.user_details));
        return response.data;
    } catch (error) {
        throw error.response.data;
    }
};
const addToCart = async ({ product_id , name , size , quantity , price , total , user_id , session_id ,  })=>{
    try {
        const { data  } = await api.post("/addtocart", {
            product_id,
            name,
            size,
            quantity,
            price,
            total,
            user_id,
            session_id
        });
        console.log("cart", data);
    } catch (error) {
        throw error.response.data.error;
    }
};
const cartList = async (userId, sessionId)=>{
    try {
        const { data  } = await api.post("/cartlist", {
            user_id: userId,
            session_id: sessionId
        });
        return data; // Returning the data for further use if needed
    } catch (error) {
        throw error.response.data.error;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;